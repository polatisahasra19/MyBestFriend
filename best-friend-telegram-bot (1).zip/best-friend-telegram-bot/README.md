# Best Friend Telegram Bot

An n8n workflow: a Telegram bot ("Buddy") that chats like a close friend, powered by Groq, with separate memory per Telegram chat.

## Flow
Telegram Trigger -> Has text? -> (true) Buddy Agent -> Send Reply
                             -> (false) Reply Text Only

Sub-nodes on Buddy Agent: Groq Chat Model (openai/gpt-oss-120b, temperature 0.8) and Simple Memory (window 10, keyed by chat id).

## Import
1. In n8n: Workflows -> Import from file -> best-friend-telegram-bot.json
2. Open each node below and select your credentials (none are stored in this file):
   - Telegram Trigger, Send Reply, Reply Text Only: Telegram API credential
   - Groq Chat Model: Groq API credential
3. Activate the workflow. n8n needs a public HTTPS URL for the Telegram webhook.

## Notes
- llama-3.3-70b-versatile was retired by Groq for free/developer tiers on 2026-08-16, so this uses openai/gpt-oss-120b.
- Messages are sent as plain text (no parse mode) with n8n attribution off.

## Test
Send /start, then "hi" (friendly reply), then a sticker ("text only" reply).
